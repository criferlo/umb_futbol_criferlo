package futbol;

public class Circle {
	public double x;
	public double y;
	public double r;
	public boolean detected;
}
