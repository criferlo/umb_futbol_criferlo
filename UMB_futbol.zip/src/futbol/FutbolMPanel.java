package futbol;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JButton;

import com.jme3.math.Vector3f;
import com.jme3.system.AppSettings;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.swing.JPanel;
import javax.swing.border.BevelBorder;
import javax.swing.JLabel;

import jssc.SerialPort;
import jssc.SerialPortException;
import jssc.SerialPortList;

import javax.swing.ButtonGroup;
import javax.swing.DefaultListModel;
import javax.swing.JComboBox;
import javax.swing.JFileChooser;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JTabbedPane;
import javax.swing.JTextField;

import org.opencv.core.Core;
import org.opencv.highgui.VideoCapture;

import javax.swing.JCheckBox;
import javax.swing.JRadioButton;

public class FutbolMPanel {

	public static boolean multipleTargetRunning = true;
	
	public static Game appGame;
	private static SerialPort serialPortIzquierda;
	private static SerialPort serialPortDerecha;
	private boolean serialPortConnectedIzquierda = false;
	private boolean serialPortConnectedDerecha = false;
	private LanzaderaCom lanzadera1;
	private LanzaderaCom lanzadera2;

	public static VideoCapture captureCam1;
	public static VideoCapture captureCam2;

	public static Vector3f targetPosition;

	public static PrintWriter fileOut;

	private JFrame frmUmbMquinaFtbol;
	final JFileChooser fc = new JFileChooser();

	private static ArrayList<Rutina> listaRutinas = new ArrayList<Rutina>();
	final static DefaultListModel<String> listModelRutinas = new DefaultListModel<String>();

	public static ArrayList<Rutina> getListaRutinas() {
		return listaRutinas;
	}

	public static void setListaRutinas(ArrayList<Rutina> listaRutinas) {
		FutbolMPanel.listaRutinas = listaRutinas;
	}

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					FutbolMPanel window = new FutbolMPanel();
					window.frmUmbMquinaFtbol.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public FutbolMPanel() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {

		System.loadLibrary(Core.NATIVE_LIBRARY_NAME);
		ballTracking.calculateCam1Parameters();
		ballTracking.calculateCam2Parameters();

		captureCam1 = new VideoCapture();
		captureCam1.open(0);
		captureCam2 = new VideoCapture();
		captureCam2.open(1);

		lanzadera1 = new LanzaderaCom();
		lanzadera2 = new LanzaderaCom();

		frmUmbMquinaFtbol = new JFrame();
		frmUmbMquinaFtbol.setTitle("UMB Máquina Fútbol");
		frmUmbMquinaFtbol.setBounds(100, 100, 736, 669);
		frmUmbMquinaFtbol.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frmUmbMquinaFtbol.getContentPane().setLayout(null);

		JTabbedPane tabbedPane = new JTabbedPane(JTabbedPane.TOP);
		tabbedPane.setBounds(12, 12, 690, 616);
		frmUmbMquinaFtbol.getContentPane().add(tabbedPane);

		JPanel panel_2 = new JPanel();
		tabbedPane.addTab("Rutinas", null, panel_2, null);
		panel_2.setLayout(null);

		final JList<String> listRutinas = new JList<String>(listModelRutinas);
		listRutinas.setBounds(12, 37, 293, 360);
		panel_2.add(listRutinas);

		JLabel lblRutinas = new JLabel("Rutinas: No, (repeticiones): ");
		lblRutinas.setBounds(12, 12, 226, 15);
		panel_2.add(lblRutinas);

		JButton btnEjecutar = new JButton("Ejecutar");
		btnEjecutar.setBounds(12, 416, 117, 25);
		panel_2.add(btnEjecutar);

		JButton btnAgregar = new JButton("Agregar");
		btnAgregar.setBounds(317, 46, 117, 25);
		panel_2.add(btnAgregar);

		JButton btnEditar = new JButton("Editar");
		btnEditar.setBounds(317, 83, 117, 25);
		panel_2.add(btnEditar);

		JButton btnSubir = new JButton("Subir");
		btnSubir.setBounds(317, 116, 117, 25);
		panel_2.add(btnSubir);

		JButton btnBajar = new JButton("Bajar");
		btnBajar.setBounds(317, 151, 117, 25);
		panel_2.add(btnBajar);

		JButton btnEliminar = new JButton("Eliminar");
		btnEliminar.setBounds(317, 188, 117, 25);
		panel_2.add(btnEliminar);

		JButton btnGuardar = new JButton("Guardar");
		btnGuardar.setBounds(317, 320, 117, 25);
		panel_2.add(btnGuardar);

		JButton btnAbrir = new JButton("Abrir");
		btnAbrir.setBounds(317, 357, 117, 25);
		panel_2.add(btnAbrir);
		btnAbrir.addActionListener(new ActionListener() {
			@SuppressWarnings("unchecked")
			public void actionPerformed(ActionEvent e) {

				int returnVal = fc.showOpenDialog(frmUmbMquinaFtbol);

				if (returnVal == JFileChooser.APPROVE_OPTION) {
					File file = fc.getSelectedFile();

					// Read from disk using FileInputStream
					FileInputStream f_in;
					try {
						f_in = new FileInputStream(file);

						// Read object using ObjectInputStream
						ObjectInputStream obj_in = new ObjectInputStream(f_in);

						// Read an object
						listaRutinas = (ArrayList<Rutina>) obj_in.readObject();

						obj_in.close();

					} catch (FileNotFoundException e1) {
						e1.printStackTrace();
					} catch (IOException e1) {
						e1.printStackTrace();
					} catch (ClassNotFoundException e1) {
						e1.printStackTrace();
					}

				} else {
					System.out.println("File canceled");
				}

				imprimirRutinas();

			}
		});
		btnGuardar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				int returnVal = fc.showSaveDialog(frmUmbMquinaFtbol);

				if (returnVal == JFileChooser.APPROVE_OPTION) {
					File file = fc.getSelectedFile();

					try {
						FileOutputStream f_out = new FileOutputStream(file);

						ObjectOutputStream obj_out = new ObjectOutputStream(f_out);

						obj_out.writeObject(listaRutinas);
						obj_out.close();

					} catch (FileNotFoundException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					} catch (IOException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}

				} else {
					System.out.println("File canceled");
				}

			}
		});
		btnEliminar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int index = listRutinas.getSelectedIndex();
				listaRutinas.remove(index);
				imprimirRutinas();
			}
		});
		btnBajar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Rutina tempRutina1;
				Rutina tempRutina2;

				int index = listRutinas.getSelectedIndex();
				if (index == listaRutinas.size() - 1)
					return;

				tempRutina1 = listaRutinas.get(index);
				tempRutina2 = listaRutinas.get(index + 1);

				listaRutinas.set(index, tempRutina2);
				listaRutinas.set(index + 1, tempRutina1);

				imprimirRutinas();

				listRutinas.setSelectedIndex(index + 1);

			}
		});
		btnSubir.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Rutina tempRutina1;
				Rutina tempRutina2;

				int index = listRutinas.getSelectedIndex();
				if (index == 0)
					return;

				tempRutina1 = listaRutinas.get(index);
				tempRutina2 = listaRutinas.get(index - 1);

				listaRutinas.set(index, tempRutina2);
				listaRutinas.set(index - 1, tempRutina1);

				imprimirRutinas();

				listRutinas.setSelectedIndex(index - 1);

			}
		});
		btnEditar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new RutinaPanel().setVisible(true, listaRutinas.get(listRutinas.getSelectedIndex()));
			}
		});
		btnAgregar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new RutinaPanel().setVisible(true);
			}
		});

		JPanel panel_3 = new JPanel();
		tabbedPane.addTab("Usuario", null, panel_3, null);
		panel_3.setLayout(null);

		JLabel lblCedula = new JLabel("Cedula:");
		lblCedula.setBounds(12, 12, 63, 17);
		panel_3.add(lblCedula);

		textFieldCedula = new JTextField();
		textFieldCedula.setBounds(78, 11, 132, 19);
		panel_3.add(textFieldCedula);
		textFieldCedula.setColumns(10);

		JButton btnBuscar = new JButton("Buscar");
		btnBuscar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				SQLQuery sql1 = new SQLQuery();
				try {

					sql1.conectar("127.0.0.1", "futbol1", "root", "temadkdk");

					// the mysql insert statement
					String query = "SELECT `cedula`, `nombre`, `apellidos`, `edad`, `estatura`, `peso`, `institucion`, "
							+ "`fechaRegistro` FROM `jugadores` WHERE cedula=" + textFieldCedula.getText();
					System.out.println(query);
					sql1.consulta = sql1.conn.prepareStatement(query);
					sql1.datos = sql1.consulta.executeQuery();
					if (sql1.datos.next()) {
						textFieldNombre.setText(sql1.datos.getString("nombre"));
						textFieldApellidos.setText(sql1.datos.getString("apellidos"));
						textFieldEdad.setText(Integer.toString(sql1.datos.getInt("edad")));
						textFieldEstatura.setText(Integer.toString(sql1.datos.getInt("estatura")));
						textFieldPeso.setText(Integer.toString(sql1.datos.getInt("peso")));
						textFieldInstitucion.setText(sql1.datos.getString("institucion"));
						labelFechaRegistro.setText(sql1.datos.getString("fechaRegistro"));
					} else {
						JOptionPane.showMessageDialog(null, "No fueron encontrados registros con la cedula: " + textFieldCedula.getText(), "No encontrado",
								JOptionPane.INFORMATION_MESSAGE);
					}

					sql1.desconectar();
				} catch (SQLException ex) {
					ex.printStackTrace();
				} catch (ClassNotFoundException e1) {
					e1.printStackTrace();
				}

			}

		});
		btnBuscar.setBounds(237, 12, 117, 25);
		panel_3.add(btnBuscar);

		JLabel lblNombre = new JLabel("Nombre:");
		lblNombre.setBounds(12, 68, 70, 15);
		panel_3.add(lblNombre);

		textFieldNombre = new JTextField();
		textFieldNombre.setBounds(88, 66, 214, 19);
		panel_3.add(textFieldNombre);
		textFieldNombre.setColumns(10);

		JLabel lblApellidos = new JLabel("Apellidos:");
		lblApellidos.setBounds(12, 95, 70, 15);
		panel_3.add(lblApellidos);

		textFieldApellidos = new JTextField();
		textFieldApellidos.setBounds(98, 93, 204, 19);
		panel_3.add(textFieldApellidos);
		textFieldApellidos.setColumns(10);

		JLabel lblEdad = new JLabel("Edad:");
		lblEdad.setBounds(12, 122, 70, 15);
		panel_3.add(lblEdad);

		textFieldEdad = new JTextField();
		textFieldEdad.setBounds(122, 120, 180, 19);
		panel_3.add(textFieldEdad);
		textFieldEdad.setColumns(10);

		JLabel lblEstatura = new JLabel("Estatura (cm):");
		lblEstatura.setBounds(12, 149, 107, 15);
		panel_3.add(lblEstatura);

		textFieldEstatura = new JTextField();
		textFieldEstatura.setBounds(122, 147, 180, 19);
		panel_3.add(textFieldEstatura);
		textFieldEstatura.setColumns(10);

		JLabel lblPesokg = new JLabel("Peso (kg):");
		lblPesokg.setBounds(12, 176, 107, 15);
		panel_3.add(lblPesokg);

		textFieldPeso = new JTextField();
		textFieldPeso.setBounds(122, 174, 180, 19);
		panel_3.add(textFieldPeso);
		textFieldPeso.setColumns(10);

		JLabel lblInstitucin = new JLabel("Institución:");
		lblInstitucin.setBounds(12, 203, 107, 15);
		panel_3.add(lblInstitucin);

		textFieldInstitucion = new JTextField();
		textFieldInstitucion.setBounds(122, 201, 180, 19);
		panel_3.add(textFieldInstitucion);
		textFieldInstitucion.setColumns(10);

		JButton btnCrear = new JButton("Crear");
		btnCrear.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				SQLQuery sql1 = new SQLQuery();
				try {
					sql1.conectar("127.0.0.1", "futbol1", "root", "temadkdk");

					// the mysql insert statement
					String query = "INSERT INTO `jugadores`(`cedula`, `nombre`, `apellidos`, `edad`, `estatura`, "
							+ "`peso`, `institucion`, `fechaRegistro`) VALUES (?,?,?,?,?,?,?,NOW());";
					System.out.println(query);
					sql1.consulta = sql1.conn.prepareStatement(query);

					sql1.consulta.setInt(1, Integer.parseInt(textFieldCedula.getText()));
					sql1.consulta.setString(2, textFieldNombre.getText());
					sql1.consulta.setString(3, textFieldApellidos.getText());
					sql1.consulta.setInt(4, Integer.parseInt(textFieldEdad.getText()));
					sql1.consulta.setInt(5, Integer.parseInt(textFieldEstatura.getText()));
					sql1.consulta.setInt(6, Integer.parseInt(textFieldPeso.getText()));
					sql1.consulta.setString(7, textFieldInstitucion.getText());

					sql1.consulta.execute();

				} catch (SQLException ex) {
					ex.printStackTrace();
				} catch (ClassNotFoundException e1) {
					e1.printStackTrace();
				}
			}
		});
		btnCrear.setBounds(173, 306, 117, 25);
		panel_3.add(btnCrear);

		JButton btnLeer = new JButton("Leer");
		btnLeer.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				SQLQuery sql1 = new SQLQuery();
				try {
					sql1.conectar("127.0.0.1", "jugadores", "root", "temadkdk");
					sql1.consulta = sql1.conn.prepareStatement("SELECT id, name FROM person");
					sql1.datos = sql1.consulta.executeQuery();
					while (sql1.datos.next()) {
						System.out.println("id: " + sql1.datos.getInt("cedula") + " nombre: " + sql1.datos.getString("name"));
					}
				} catch (SQLException ex) {
					ex.printStackTrace();
				} catch (ClassNotFoundException e1) {
					e1.printStackTrace();
				}
			}
		});
		btnLeer.setBounds(38, 306, 117, 25);
		panel_3.add(btnLeer);

		JLabel lblFechaRegistro = new JLabel("Fecha registro:");
		lblFechaRegistro.setBounds(12, 228, 132, 15);
		panel_3.add(lblFechaRegistro);

		labelFechaRegistro = new JLabel("00-00-0000");
		labelFechaRegistro.setBounds(156, 228, 107, 15);
		panel_3.add(labelFechaRegistro);

		panel_1 = new JPanel();
		tabbedPane.addTab("Configuración", null, panel_1, null);
		panel_1.setLayout(null);

		JButton btnIniciar = new JButton("Iniciar");
		btnIniciar.setBounds(141, 186, 117, 25);
		panel_1.add(btnIniciar);

		JButton btnLanzar = new JButton("Lanzar");
		btnLanzar.setBounds(12, 186, 117, 25);
		panel_1.add(btnLanzar);

		JButton btnParar = new JButton("Parar");
		btnParar.setBounds(270, 186, 117, 25);
		panel_1.add(btnParar);

		JPanel panel = new JPanel();
		panel.setBounds(12, 223, 328, 113);
		panel_1.add(panel);
		panel.setBorder(new BevelBorder(BevelBorder.LOWERED, null, null, null, null));
		panel.setLayout(null);

		JLabel lblLanzadoraDeBalones = new JLabel("Lanzadora de balones izquierda:");
		lblLanzadoraDeBalones.setBounds(12, 12, 289, 15);
		panel.add(lblLanzadoraDeBalones);

		JLabel lblPuertoSerial = new JLabel("Puerto serial: ");
		lblPuertoSerial.setBounds(14, 39, 138, 15);
		panel.add(lblPuertoSerial);

		comboBoxSerialPortIzquierda = new JComboBox<String>();
		comboBoxSerialPortIzquierda.setBounds(117, 34, 147, 24);
		panel.add(comboBoxSerialPortIzquierda);

		btnConectarIzquierda = new JButton("Conectar");
		btnConectarIzquierda.setBounds(12, 66, 138, 25);
		panel.add(btnConectarIzquierda);

		chckbxActivaLanzadera1 = new JCheckBox("Activa");
		chckbxActivaLanzadera1.setBounds(172, 66, 129, 23);
		panel.add(chckbxActivaLanzadera1);

		JButton btnTest = new JButton("Open F.");
		btnTest.setBounds(352, 223, 117, 25);
		panel_1.add(btnTest);

		JPanel panel_4 = new JPanel();
		panel_4.setLayout(null);
		panel_4.setBorder(new BevelBorder(BevelBorder.LOWERED, null, null, null, null));
		panel_4.setBounds(12, 348, 328, 113);
		panel_1.add(panel_4);

		JLabel lblLanzadoraDeBalones_1 = new JLabel("Lanzadora de balones derecha:");
		lblLanzadoraDeBalones_1.setBounds(12, 12, 289, 15);
		panel_4.add(lblLanzadoraDeBalones_1);

		JLabel label_1 = new JLabel("Puerto serial: ");
		label_1.setBounds(14, 39, 138, 15);
		panel_4.add(label_1);

		comboBoxSerialPortDerecha = new JComboBox<String>();
		comboBoxSerialPortDerecha.setBounds(117, 34, 147, 24);
		panel_4.add(comboBoxSerialPortDerecha);

		btnConectarDerecha = new JButton("Conectar");
		btnConectarDerecha.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (serialPortConnectedDerecha == false) {
					serialPortDerecha = new SerialPort((String) comboBoxSerialPortDerecha.getSelectedItem());
					try {
						serialPortDerecha.openPort();// Open serial port
						System.out.println("Derecha Serial port opend");
						serialPortDerecha.setParams(SerialPort.BAUDRATE_9600, SerialPort.DATABITS_8, SerialPort.STOPBITS_1, SerialPort.PARITY_NONE);
						serialPortConnectedDerecha = true;

						btnConectarDerecha.setText("Desconectar");
						lanzadera2.setSerialPort(serialPortDerecha);

					} catch (SerialPortException ex) {
						System.out.println(ex);
					}
				} else {
					try {
						serialPortDerecha.closePort();
						System.out.println("Derecha serial port closed");
						serialPortConnectedDerecha = false;
						btnConectarDerecha.setText("Conectar");

					} catch (SerialPortException e1) {
						e1.printStackTrace();
					}
				}
			}
		});
		btnConectarDerecha.setBounds(12, 66, 138, 25);
		panel_4.add(btnConectarDerecha);

		chckbxActivaLanzadera2 = new JCheckBox("Activa");
		chckbxActivaLanzadera2.setBounds(172, 68, 129, 23);
		panel_4.add(chckbxActivaLanzadera2);

		final JButton btnMotiontracking = new JButton("MotionTracking");
		btnMotiontracking.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				motionThread.start();
				btnMotiontracking.setText("Started");
			}
		});
		btnMotiontracking.setBounds(12, 468, 167, 25);
		panel_1.add(btnMotiontracking);

		JButton btnGetPos = new JButton("Get Pos");
		btnGetPos.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				System.out.println("Pos x: " + ballTracking.getxPos());
				System.out.println("Pos y: " + ballTracking.getyPos());
				// appGame.setTubo(ballTracking.getxPos());
			}
		});
		btnGetPos.setBounds(191, 468, 117, 25);
		panel_1.add(btnGetPos);

		textFieldFileName = new JTextField();
		textFieldFileName.setText("archivo");
		textFieldFileName.setBounds(447, 360, 114, 19);
		panel_1.add(textFieldFileName);
		textFieldFileName.setColumns(10);

		textFieldPrueba = new JTextField();
		textFieldPrueba.setText("pecho");
		textFieldPrueba.setBounds(447, 391, 114, 19);
		panel_1.add(textFieldPrueba);
		textFieldPrueba.setColumns(10);

		JButton btnTerminar = new JButton("Cerrar F.");
		btnTerminar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				fileOut.close();
			}
		});
		btnTerminar.setBounds(352, 484, 117, 25);
		panel_1.add(btnTerminar);

		textFieldNombre1 = new JTextField();
		textFieldNombre1.setText("nombre");
		textFieldNombre1.setBounds(447, 325, 114, 19);
		panel_1.add(textFieldNombre1);
		textFieldNombre1.setColumns(10);

		JLabel lblNombre_1 = new JLabel("Nombre");
		lblNombre_1.setBounds(359, 321, 70, 15);
		panel_1.add(lblNombre_1);

		JLabel lblNewLabel = new JLabel("File name");
		lblNewLabel.setBounds(359, 362, 70, 15);
		panel_1.add(lblNewLabel);

		JLabel lblPrueba = new JLabel("Prueba");
		lblPrueba.setBounds(359, 393, 70, 15);
		panel_1.add(lblPrueba);

		JButton btnTuneTracking = new JButton("Tune Tracking");
		btnTuneTracking.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				TuneTracking tuneTracking = new TuneTracking();
				tuneTracking.setVisible(true);
			}
		});
		btnTuneTracking.setBounds(12, 505, 167, 25);
		panel_1.add(btnTuneTracking);

		JLabel lblAnguloCam = new JLabel("cam2AngleX:");
		lblAnguloCam.setBounds(12, 78, 117, 15);
		panel_1.add(lblAnguloCam);

		labelCam2angleX = new JLabel("0");
		labelCam2angleX.setBounds(135, 78, 70, 15);
		panel_1.add(labelCam2angleX);

		JLabel lblCamanglex = new JLabel("cam2AngleZ:");
		lblCamanglex.setBounds(12, 105, 117, 15);
		panel_1.add(lblCamanglex);

		labelCam2angleZ = new JLabel("0");
		labelCam2angleZ.setBounds(135, 105, 70, 15);
		panel_1.add(labelCam2angleZ);

		JLabel lblBallxpos = new JLabel("ballXpos:");
		lblBallxpos.setBounds(352, 12, 117, 15);
		panel_1.add(lblBallxpos);

		labelBallXpos = new JLabel("0");
		labelBallXpos.setBounds(475, 12, 70, 15);
		panel_1.add(labelBallXpos);

		JLabel lblBallypos = new JLabel("ballYpos:");
		lblBallypos.setBounds(352, 39, 117, 15);
		panel_1.add(lblBallypos);

		labelBallYPos = new JLabel("0");
		labelBallYPos.setBounds(475, 39, 70, 15);
		panel_1.add(labelBallYPos);

		JLabel lblVelAnimacin = new JLabel("Vel. animación: ");
		lblVelAnimacin.setBounds(171, 132, 122, 15);
		panel_1.add(lblVelAnimacin);

		textFieldVelocidadAnimacion = new JTextField();
		textFieldVelocidadAnimacion.setText("10");
		textFieldVelocidadAnimacion.setBounds(288, 130, 114, 19);
		panel_1.add(textFieldVelocidadAnimacion);
		textFieldVelocidadAnimacion.setColumns(10);

		JLabel lblA = new JLabel("a");
		lblA.setBounds(240, 12, 26, 15);
		panel_1.add(lblA);

		JLabel lblB = new JLabel("b");
		lblB.setBounds(240, 39, 26, 15);
		panel_1.add(lblB);

		labelA = new JLabel("0");
		labelA.setBounds(288, 12, 70, 15);
		panel_1.add(labelA);

		labelB = new JLabel("0");
		labelB.setBounds(287, 39, 70, 15);
		panel_1.add(labelB);

		JLabel lblCamanglex_1 = new JLabel("cam1AngleX:");
		lblCamanglex_1.setBounds(12, 12, 117, 15);
		panel_1.add(lblCamanglex_1);

		JLabel lblCamanglez = new JLabel("cam1AngleZ:");
		lblCamanglez.setBounds(12, 39, 117, 15);
		panel_1.add(lblCamanglez);

		labelCam1angleZ = new JLabel("0");
		labelCam1angleZ.setBounds(135, 39, 70, 15);
		panel_1.add(labelCam1angleZ);

		labelCam1angleX = new JLabel("0");
		labelCam1angleX.setBounds(135, 12, 70, 15);
		panel_1.add(labelCam1angleX);

		JLabel lblBallzpos = new JLabel("ballZpos:");
		lblBallzpos.setBounds(352, 66, 117, 15);
		panel_1.add(lblBallzpos);

		labelBallZPos = new JLabel("0");
		labelBallZPos.setBounds(475, 66, 70, 15);
		panel_1.add(labelBallZPos);

		rdbtnJugadorVirtual = new JRadioButton("Jugador virtual");
		rdbtnJugadorVirtual.setSelected(true);
		rdbtnJugadorVirtual.setBounds(12, 128, 149, 23);
		panel_1.add(rdbtnJugadorVirtual);

		rdbtnTarget = new JRadioButton("Blanco");
		rdbtnTarget.setBounds(12, 155, 149, 23);
		panel_1.add(rdbtnTarget);

		ButtonGroup group1 = new ButtonGroup();
		group1.add(rdbtnJugadorVirtual);
		group1.add(rdbtnTarget);

		btnTest.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				try {
					fileOut = new PrintWriter(new FileWriter(textFieldFileName.getText()));
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}

				// Save the Galileo List
				fileOut.println("Datos:");

			}
		});
		btnConectarIzquierda.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				if (serialPortConnectedIzquierda == false) {
					serialPortIzquierda = new SerialPort((String) comboBoxSerialPortIzquierda.getSelectedItem());
					try {
						serialPortIzquierda.openPort();// Open serial port
						System.out.println("Izquierda serial port opend");
						serialPortIzquierda.setParams(SerialPort.BAUDRATE_9600, SerialPort.DATABITS_8, SerialPort.STOPBITS_1, SerialPort.PARITY_NONE);
						serialPortConnectedIzquierda = true;

						btnConectarIzquierda.setText("Desconectar");
						lanzadera1.setSerialPort(serialPortIzquierda);

					} catch (SerialPortException ex) {
						System.out.println(ex);
					}
				} else {
					try {
						serialPortIzquierda.closePort();
						System.out.println("Izquierda serial port closed");
						serialPortConnectedIzquierda = false;
						btnConectarIzquierda.setText("Conectar");

					} catch (SerialPortException e1) {
						e1.printStackTrace();
					}
				}

			}
		});
		btnParar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				appGame.playerStop = true;
			}
		});
		btnLanzar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				ballTracking.shoted = true;

				try {
					if (chckbxActivaLanzadera1.isSelected())
						lanzadera1.shot();
					if (chckbxActivaLanzadera2.isSelected())
						lanzadera2.shot();

					Thread.sleep(500);
				} catch (InterruptedException e1) {
					e1.printStackTrace();
				}

				if (rdbtnJugadorVirtual.isSelected()) {
					float speed = Float.parseFloat(textFieldVelocidadAnimacion.getText()) / 10;
					appGame.player1.anim("correr1", speed);
				}

				if (rdbtnTarget.isSelected()) {
					targetPosition = new Vector3f(0f, (float) (Math.random() * 1.7f + 0.2f), (float) (Math.random() * 7f + 1f));
					appGame.blueTarget = true;
					appGame.updateTarget = true;
				}
				
			}
		});
		btnIniciar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				gameThread.start();
			}
		});

		System.out.println("The ports: ");
		String[] portNames = SerialPortList.getPortNames();
		for (int i = 0; i < portNames.length; i++) {
			System.out.println(portNames[i]);
			comboBoxSerialPortIzquierda.addItem(portNames[i]);
			comboBoxSerialPortDerecha.addItem(portNames[i]);
		}
	}

	// Game engine thread
	Thread gameThread = new Thread(new Runnable() {
		@Override
		public void run() {
			appGame = new Game();
			appGame.setShowSettings(false);
			AppSettings settings = new AppSettings(true);
			settings.put("Width", 3072);
			settings.put("Height", 716);

			 settings.put("Width", 3072 / 2);
			 settings.put("Height", 716 / 2);

			settings.put("Title", "Entrenador de fútbol UMB");
			settings.put("VSync", true);
			// Anti-Aliasing
			settings.put("Samples", 4);

			// No pause when focus is lost
			appGame.setPauseOnLostFocus(false);
			appGame.setSettings(settings);

			appGame.start(); // start the game
		}

	});
	private JComboBox<String> comboBoxSerialPortIzquierda;
	private JButton btnConectarIzquierda;
	private JComboBox<String> comboBoxSerialPortDerecha;
	private JButton btnConectarDerecha;
	private JTextField textFieldCedula;
	private JTextField textFieldNombre;
	private JTextField textFieldApellidos;
	private JTextField textFieldEdad;
	private JTextField textFieldEstatura;
	private JTextField textFieldPeso;
	private JTextField textFieldInstitucion;
	private JLabel labelFechaRegistro;

	public static void imprimirRutinas() {

		listModelRutinas.clear();
		String rep;
		for (int i = 0; i < listaRutinas.size(); i++) {
			rep = Integer.toString(listaRutinas.get(i).getRepeticiones());
			listModelRutinas.addElement((i + 1) + ", (" + rep + "): " + listaRutinas.get(i).getNombre());
		}

	}

	// Game engine thread
	Thread motionThread = new Thread(new Runnable() {
		@Override
		public void run() {
			try {
				ballTracking.tracking();
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

	});
	private JTextField textFieldFileName;
	public static JTextField textFieldPrueba;
	public static JTextField textFieldNombre1;
	public static JLabel labelCam2angleX;
	public static JPanel panel_1;
	public static JLabel labelCam2angleZ;
	public static JLabel labelBallXpos;
	public static JLabel labelBallYPos;
	private JTextField textFieldVelocidadAnimacion;
	public static JLabel labelB;
	public static JLabel labelA;
	public static JLabel labelCam1angleZ;
	public static JLabel labelCam1angleX;
	public static JLabel labelBallZPos;
	public static JRadioButton rdbtnJugadorVirtual;
	public static JRadioButton rdbtnTarget;
	
	// Game engine thread
	Thread multipleTarget = new Thread(new Runnable() {
		
		@Override
		public void run() {
			multipleTargetRunning = true;

			while(multipleTargetRunning){
				
				ballTracking.shoted = true;

				try {
					if (chckbxActivaLanzadera1.isSelected())
						lanzadera1.shot();
					if (chckbxActivaLanzadera2.isSelected())
						lanzadera2.shot();

					Thread.sleep(500);
				} catch (InterruptedException e1) {
					e1.printStackTrace();
				}

				if (rdbtnJugadorVirtual.isSelected()) {
					float speed = Float.parseFloat(textFieldVelocidadAnimacion.getText()) / 10;
					appGame.player1.anim("correr1", speed);
				}

				if (rdbtnTarget.isSelected()) {
					targetPosition = new Vector3f(0f, (float) (Math.random() * 1.7f + 0.2f), (float) (Math.random() * 7f + 1f));
					appGame.blueTarget = true;
					appGame.updateTarget = true;
				}
				
				while(ballTracking.shoted){
					try {
						Thread.sleep(100);
					} catch (InterruptedException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
				
				try {
					Thread.sleep(2000);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

				
				
			}
			
		}

	});
	private static JCheckBox chckbxActivaLanzadera1;
	private static JCheckBox chckbxActivaLanzadera2;
}
